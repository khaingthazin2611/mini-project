#! C:\Python36\python.exe
import cgi
import cgitb;cgitb.enable()

print("Content-type:text/html\n\n")

print("""
<!DOCTYPE html>
<html>
<head>
<title>ABC Job Portal</title>

</head>
<style>
body{
background-color:#ffe6ff;
}
.form fieldset{
	border-radius: 10px;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	margin: 0px 0px 10px 10px;
	border: 1px solid #FFD2D2;
	padding: 20px;
	background: #FFF4F4;
	box-shadow: inset 0px 0px 15px #FFE5E5;
	-moz-box-shadow: inset 0px 0px 15px #FFE5E5;
	-webkit-box-shadow: inset 0px 0px 15px #FFE5E5;
}
#cover{
position:absolute;
top:2em;
right:1em;
}
</style>
<section>
<div id="logo">
<img src="abc.jpg" alt="Logo"width="150" height="100" align="left";>
</div>
</section>
<body>
<form name='testform' action="RG.py" method="post">
<fieldset>
First name: <br><input type="text" name="firstname" >
<p id="err_firstname" style="color:red;"></p>
<br>
Last name: <br><input type="text" name="lastname" >
<p id="err_lastname" style="color:red;"></p>
<br>
Email: <br><input type="text" name="email" >
<p id="err_email" style="color:red;"></p>
<br>
<br>password: <br><input type="text" name="password" >
<p id="err_password" style="color:red;"></p>
<br>
<input type="hidden" name="submitted" value="1">
<input type="submit" value="Submit">
</fieldset>
<div id="cover">
<div class = "col-8">
<img src="cover.jpg" alit="cover"width="800" height="400" align="right";>
</div>
</div>
</div>
</form>
</body>
</html>
""")
