#!/Python36/python.exe
import MySQLdb
import cgi;
print("Content-type: text/html\n\n")
db = MySQLdb.connect(host="localhost", user="root", passwd="newlithan", db="minipj1")

cursor = db.cursor()
form=cgi.FieldStorage()
def getFieldValue(fieldname):
    if fieldname in form:
        return form[fieldname].value
if "submitted" in form:
    fname=getFieldValue("firstname")
    lname=getFieldValue("lastname")
    email=getFieldValue("email")
    password=getFieldValue("password")
    
    try:
        cursor.execute("insert into registers (firstname,lastname,email,password) values('{0}','{1}','{2}','{3}')" .format(fname, lname,email,password))
        print('Hi',fname,'your data is successfully inserted')
        db.commit()
    except:
        print("Error occured")
        db.rollback()
db.close   
